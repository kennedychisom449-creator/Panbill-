# PanBill Marketplace Edge Functions

This folder contains the two existing Supabase Edge Functions supplied for the PanBill marketplace. Their source files are preserved as received.

## Structure

- `supabase/functions/marketplace-admin/index.ts` — admin seller-application review, approval/rejection/suspension, commission setting, and audit logging.
- `supabase/functions/marketplace-seller/index.ts` — seller application registration and seller application status.

## Required Supabase environment variables

These functions read the following values from the Supabase Edge Function environment; do not commit their values to GitHub:

- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`

The service-role key must remain a server-side secret and must never be placed in browser code.

## Deployment

From the repository root, deploy each function using the Supabase CLI after linking the correct Supabase project:

```bash
supabase functions deploy marketplace-seller
supabase functions deploy marketplace-admin
```

Keep JWT verification enabled for both functions. Verify the deployment against the intended Supabase project before running production tests.

## Current functionality and limitations

These two functions currently implement seller application/status and admin seller review. They do not yet implement product creation/editing, storefront browsing, cart/checkout, order creation, payment verification for marketplace orders, commission ledger creation, or seller payouts. Those require separate implementation and security review.

## Review items before production use

1. Confirm the intended administrator's `panbill_admins.role` value is exactly `admin`; the admin function rejects other values.
2. Test seller registration and status using a normal authenticated test account.
3. Test admin review using an authorized admin account, including audit-log creation.
4. Consider restricting `Access-Control-Allow-Origin` from `*` to the production PanBill origin, while retaining the required headers/methods. CORS is not a substitute for authentication or authorization.
5. Consider making audit-log failure an explicit operational failure or adding reliable retry/monitoring; currently seller review can succeed even if audit insertion fails, and the response reports `audit_logged: false`.
6. Keep service-role credentials only in Supabase secrets. Never commit them.

## Important

This is a source-code backup of the two supplied functions, not a complete marketplace website or complete marketplace implementation. Existing VTU, wallet, and Paystack functions are not included or modified.
